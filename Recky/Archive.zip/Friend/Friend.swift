struct Friend: Identifiable {
    let id: String
    let username: String
}
