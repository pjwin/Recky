//
//  Recommendation.swift
//  Recky
//
//  Created by Paul Winters on 6/20/25.
//

import FirebaseFirestore
import Foundation

struct Recommendation: Identifiable, Codable {
    @DocumentID var id: String?
    var fromUID: String
    var toUID: String
    var title: String
    var type: String
    var notes: String?
    var timestamp: Date
    var vote: Bool?
    var fromUsername: String?
}
