//
//  RecommendationsView.swift
//  Recky
//
//  Created by Paul Winters on 6/20/25.
//


import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct RecommendationsView: View {
    @State private var recommendations: [Recommendation] = []
    @State private var showSendView = false

    var body: some View {
        VStack {
            if recommendations.isEmpty {
                Text("No recommendations yet.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List(recommendations) { rec in
                    VStack(alignment: .leading) {
                        Text(rec.title)
                            .font(.headline)
                        Text("Type: \(rec.type)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        if let notes = rec.notes, !notes.isEmpty {
                            Text("“\(notes)”")
                                .font(.body)
                                .italic()
                                .padding(.top, 2)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Recommendations")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button(action: {
                    showSendView = true
                }) {
                    Image(systemName: "plus")
                }
            }
        }
        .onAppear {
            startListeningForRecommendations()
        }
        .sheet(isPresented: $showSendView) {
            SendRecommendationView()
        }
    }
    
    func startListeningForRecommendations() {
        guard let myUID = Auth.auth().currentUser?.uid else { return }

        Firestore.firestore().collection("recommendations")
            .whereField("toUID", isEqualTo: myUID)
            .order(by: "timestamp", descending: true)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    print("Failed to listen to recommendations: \(error)")
                    return
                }

                guard let docs = snapshot?.documents else { return }

                self.recommendations = docs.compactMap { doc in
                    try? doc.data(as: Recommendation.self)
                }

                print("Live update: \(recommendations.count) recommendations")
            }
    }

}
