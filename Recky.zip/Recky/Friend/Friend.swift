//
//  Friend.swift
//  Recky
//
//  Created by Paul Winters on 6/22/25.
//


struct Friend: Identifiable {
    let id: String
    let username: String
}