//
//  FriendsPageView.swift
//  Recky
//
//  Created by Paul Winters on 6/18/25.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct FriendsPageView: View {
    @State private var groupedFriends: [String: [(uid: String, username: String)]] = [:]
    @State private var allFriendUIDs: [String] = []
    @State private var requestCount = 0
    @State private var showRequests = false
    @State private var showFriendSearch = false
    @State private var showGroupForm = false
    @State private var groups: [(id: String, name: String, members: [String])] = []
    @State private var isEditing = false

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Button(action: { showRequests = true }) {
                    HStack {
                        Label("Requests", systemImage: "person.crop.circle.badge.questionmark")
                            .frame(maxWidth: .infinity)
                        if requestCount > 0 {
                            Text("(\(requestCount))")
                                .foregroundColor(.red)
                        }
                    }
                }

                Button(action: { showFriendSearch = true }) {
                    Label("Add Friend", systemImage: "person.badge.plus")
                        .frame(maxWidth: .infinity)
                }

                if isEditing {
                    Button(action: { showGroupForm = true }) {
                        Label("New Group", systemImage: "plus.circle")
                            .frame(maxWidth: .infinity)
                    }
                }
            }
            .padding()

            Divider()

            List {
                ForEach(groups, id: \.(id)) { group in
                    Section(header:
                        HStack {
                            if isEditing {
                                TextField("Group Name", text: Binding(
                                    get: { group.name },
                                    set: { newValue in renameGroup(group.id, to: newValue) }
                                ))
                                .font(.headline)
                            } else {
                                Text(group.name).font(.headline)
                            }

                            Spacer()

                            if isEditing {
                                Button {
                                    deleteGroup(group)
                                } label: {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                }
                                .buttonStyle(BorderlessButtonStyle())
                            }
                        }
                    ) {
                        ForEach(groupedFriends[group.name] ?? [], id: \.(uid)) { friend in
                            HStack {
                                Text(friend.username)
                                Spacer()
                                if isEditing {
                                    Button {
                                        removeFriend(uid: friend.uid)
                                    } label: {
                                        Image(systemName: "minus.circle")
                                            .foregroundColor(.red)
                                    }
                                }
                            }
                            .onDrag {
                                NSItemProvider(object: friend.uid as NSString)
                            }
                        }
                    }
                }

                if let ungrouped = groupedFriends["Ungrouped"], !ungrouped.isEmpty {
                    ForEach(ungrouped, id: \.(uid)) { friend in
                        HStack {
                            Text(friend.username)
                            Spacer()
                            if isEditing {
                                Button {
                                    removeFriend(uid: friend.uid)
                                } label: {
                                    Image(systemName: "minus.circle")
                                        .foregroundColor(.red)
                                }
                            }
                        }
                        .onDrag {
                            NSItemProvider(object: friend.uid as NSString)
                        }
                    }
                }
            }
        }
        .navigationTitle("Friends")
        .navigationBarItems(trailing: Button(isEditing ? "Done" : "Edit") {
            isEditing.toggle()
        })
        .onAppear {
            loadRequests()
            loadGroupedFriends()
        }
        .sheet(isPresented: $showRequests) {
            NavigationView {
                FriendRequestsView()
                    .navigationTitle("Friend Requests")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showRequests = false
                            }
                        }
                    }
            }
        }
        .sheet(isPresented: $showFriendSearch) {
            NavigationView {
                FriendSearchView()
                    .navigationTitle("Add Friend")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showFriendSearch = false
                            }
                        }
                    }
            }
        }
        .sheet(isPresented: $showGroupForm, onDismiss: loadGroupedFriends) {
            NavigationView {
                CreateFriendGroupView()
                    .navigationTitle("New Group")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") {
                                showGroupForm = false
                            }
                        }
                    }
            }
        }
    }

    func loadRequests() {
        guard let myUID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()

        db.collection("users").document(myUID).addSnapshotListener { snapshot, _ in
            let requests = snapshot?.data()?["friendRequests"] as? [String] ?? []
            requestCount = requests.count
        }
    }

    func loadGroupedFriends() {
        guard let myUID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()

        db.collection("users").document(myUID).getDocument { doc, _ in
            guard let data = doc?.data(), let friendUIDs = data["friends"] as? [String] else { return }

            allFriendUIDs = friendUIDs

            db.collection("groups").whereField("ownerId", isEqualTo: myUID).getDocuments { snapshot, _ in
                var usedUIDs = Set<String>()
                var grouped: [String: [(uid: String, username: String)]] = [:]
                var loadedGroups: [(String, String, [String])] = []

                for doc in snapshot?.documents ?? [] {
                    let id = doc.documentID
                    let name = doc.get("name") as? String ?? "Unnamed"
                    let members = doc.get("memberUIDs") as? [String] ?? []

                    loadedGroups.append((id, name, members))

                    for uid in members where friendUIDs.contains(uid) {
                        usedUIDs.insert(uid)
                        fetchFriend(uid: uid) { username in
                            grouped[name, default: []].append((uid, username))
                        }
                    }
                }

                let ungrouped = friendUIDs.filter { !usedUIDs.contains($0) }
                for uid in ungrouped {
                    fetchFriend(uid: uid) { username in
                        grouped["Ungrouped", default: []].append((uid, username))
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    groupedFriends = grouped
                    groups = loadedGroups
                }
            }
        }
    }

    func fetchFriend(uid: String, completion: @escaping (String) -> Void) {
        let db = Firestore.firestore()
        db.collection("users").document(uid).getDocument { doc, _ in
            let username = doc?.get("username") as? String ?? "Unknown"
            completion(username)
        }
    }

    func deleteGroup(_ group: (id: String, name: String, members: [String])) {
        let db = Firestore.firestore()
        db.collection("groups").document(group.id).delete { error in
            if let error = error {
                print("Error deleting group: \(error)")
            } else {
                loadGroupedFriends()
            }
        }
    }
}
